function FormComponent({ formData, setFormData, isUpdate }) {

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  }

  return (
    <form>
      <div className="form-group">
        <label>Emp Name</label>
        <input
          type="text"
          className="form-control"
          name="empName"
          value={formData.empName}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Emp Email</label>
        <input
          type="email"
          className="form-control"
          name="empEmail"
          value={formData.empEmail}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Emp Role</label>
        <input
          type="text"
          className="form-control"
          name="empRole"
          value={formData.empRole}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Emp Department</label>
        <input
          type="text"
          className="form-control"
          name="empDepartment"
          value={formData.empDepartment}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Emp Profile</label>
        <input
          type="text"
          className="form-control"
          name="empProfile"
          value={formData.empProfile}
          onChange={handleChange}
        />
      </div>
    </form>
  );
}

export default FormComponent;
