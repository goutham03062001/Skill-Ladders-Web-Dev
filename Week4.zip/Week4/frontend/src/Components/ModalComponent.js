import { useState } from "react";
import FormComponent from "./FormComponent";
import axios from "axios";
function ModalComponent({ listOfEmployees , updateCurrentEmp}) {

  const [empList, setEmpList] = useState([]);

  const [formData, setFormData] = useState({
    empName: "",
    empEmail: "",
    empRole: "",
    empDepartment: "",
    empProfile: ""
  });

  async function addNewEmp() {
    console.log("calling create emp api")
    //call the createEmp Api
    const response = await axios.post("http://localhost:7000/createEmployee",{
      empName : formData.empName,
      empEmail : formData.empEmail,
      empRole : formData.empRole,
      empProfile : formData.empProfile,
      empDepartment : formData.empDepartment
    }).then((data)=>{
      console.log("create new employee api res - ");
      console.log(data);
      return alert("Employee created successfully, please refresh the page to see the updated list");
    }).catch(err=>{
      console.log("error while requesting create new emp - "+err)
    })

    // setEmpList(prevList => {
    //   const updatedList = [...prevList, formData];
    //   listOfEmployees(updatedList); 
    //   return updatedList;
    // });

    // Reset form
    setFormData({
      empName: "",
      empEmail: "",
      empRole: "",
      empDepartment: "",
      empProfile: ""
    });
   
  }

  return (
    <div className="modal" role="dialog" id="exampleModal">
      <div className="modal-dialog" role="document">
        <div className="modal-content">

          <div className="modal-header">
            <h5 className="modal-title">Add Employee</h5>
            <button type="button" className="close" data-dismiss="modal">
              <span>&times;</span>
            </button>
          </div>

          <div className="modal-body">
            <FormComponent
              formData={formData}
              setFormData={setFormData}
              sendFormData={(data) => setFormData(data)}
              
            />
          </div>

          <div className="modal-footer">
            <button className="btn btn-primary" onClick={addNewEmp}>
              Save changes
            </button>
            <button className="btn btn-secondary" data-dismiss="modal">
              Close
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}

export default ModalComponent;
