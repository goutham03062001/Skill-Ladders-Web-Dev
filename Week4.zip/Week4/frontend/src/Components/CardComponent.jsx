import React,{useState} from "react";
import axios from "axios";
import UpdateModalComponent from "./UpdateModelComponent";
function CardComponent({empList, updateCurrentEmployeeCallBack}){
  async function removeCurrentEmp(index){
    try{
      const empId = index;
      const response = await axios.delete("http://localhost:7000/deleteEmployee/"+empId);
      if(response.status === 200){
        console.log("employee deleted successfully"); // refresh the page,  you can able to see the updated list
        return alert("employee deleted successfully, please refresh the page to see the updated list");
      }else{
        console.log("failed to delete employee");
        console.log(response);
      }
    }
    catch(err){
      console.log(err);
    }
  }
  function updateCurrentEp(index){
    try{
      
      updateCurrentEmployeeCallBack(index);
    }
    catch(err){
      console.log(err);
    }
  }
    return(<>
    {
        empList && empList.length>0 ? empList.map((emp,index)=>{
            return(<div className="card col-md-3" key={index}>
            <div className="card-body">
              <img src={emp.profile} className="card-img-top" alt="..." style={{width:180,height:200}}/>
            <div className="card-body">
              <h5 className="card-title">{emp.name}</h5>
              <p className="card-text">{emp.email}</p>
              <p className="card-text">{emp.role}</p>
              <p className="card-text">{emp.department}</p>
            </div>
            <div className="btn-group">
              <div className="btn btn-danger px-5" onClick={()=>removeCurrentEmp(emp._id)}>remove</div>
              <div className="btn btn-success px-5"
              data-toggle="modal" data-target="#updateModal"
               onClick={()=>updateCurrentEp(emp._id)}
              >update</div>
               
            </div>
            </div>
          </div>)
         
        }) : <p>No Employees Found</p>
    }


{/* <p>{empList && empList[0].empName}</p> */}
        {/* {!empList && <p>No Employees Found</p>} */}
    </>);
}
export default CardComponent;