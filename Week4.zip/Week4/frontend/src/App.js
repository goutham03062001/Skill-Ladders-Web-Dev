import {useState,useEffect} from "react";
import './App.css';
import CardComponent from './Components/CardComponent';
import ModalComponent from "./Components/ModalComponent";
import axios from "axios";
import UpdateModalComponent from "./Components/UpdateModelComponent";
function App() {
  const[showModal,setShowModal] = useState(false);
  const[showUpdateModal,setShowUpdateModal] = useState(false);
  const[empList,setEmpList] = useState([]);
  const[empId,setEmpId] = useState("");
  const apiEndpoint = "http://localhost:7000/fetch/getAllEmp";
  
  useEffect( ()=>{
console.log("calling get all emp api");
   callAllUsers();
   async function callAllUsers()
   {
    const response = await axios.get(apiEndpoint,{}).then((data)=>{
      console.log(data);
      if(data.data){
        setEmpList(data.data);
      }else{
        setEmpList([]);
      }
      
    }).catch(err=>{
      console.log("error while calling get all emp - "+err);
    })

   }
    // setEmpList(empList);  
  },[])
  function addUserModal(){
    setShowModal(true);
  }
  function listOfEmployees(list){
    setEmpList(list);
    console.log(list);
  }
  function updateCurrentEmployeeCallBack(index){
    setShowUpdateModal(true);
    setEmpId(index);
  }
  return (
  <div className="container-fluid">
  <div className="row">
    <div className='col-12 d-flex justify-content-end mt-5'>
      <button className='btn btn-primary btn-md px-5' onClick={addUserModal}
      data-toggle="modal" data-target="#exampleModal">add</button>
    </div>
  </div>
  <div className="row">
    {showModal && (<>
      <ModalComponent listOfEmployees={listOfEmployees} />

    </>)}
    {showUpdateModal && (<>
      <UpdateModalComponent currentEmployeeData={empList.find(emp => emp._id === empId)} />

    </>)}
  </div>
 
 <div className="row">
   <CardComponent empList = {empList}
    removeCurrentEmp={(index)=>{
      const updatedEmpList = empList.filter((emp, i) => i !== index);
      setEmpList(updatedEmpList);
    }}
    updateCurrentEmployeeCallBack={updateCurrentEmployeeCallBack}
   />
 </div>
  </div>
  );
}

export default App;
