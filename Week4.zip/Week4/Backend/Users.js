const mongoose = require("mongoose");
//Schemas are collections/tables in sql
//name, email, password, role
const userSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    role:{
        type:String,
        required:true
    }
});

module.exports = UserModel = mongoose.model("SkillLaddersUsers", userSchema);