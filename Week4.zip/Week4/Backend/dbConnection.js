const mongoose = require("mongoose");

const DbConnectionUrl = "mongodb+srv://gouthamp0306_db_user:trXGW0coZ5Qq3OSi@cluster0.r6hz6cn.mongodb.net/";

mongoose.connect(DbConnectionUrl,{ useNewUrlParser: true, useUnifiedTopology: true }).then(()=>{
    console.log("Connected to MongoDB successfully");
}).catch((err)=>{
    console.log("Error while connecting to MongoDB",err);
})