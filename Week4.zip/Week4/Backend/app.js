const express = require("express");
const app = express();
const cors = require("cors");
const dbConnection = require("./dbConnection");
const port = 7000;
const User = require("./Users.js");

app.use(cors({
  origin: "http://localhost:3000", // your React app URL
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true // if using cookies/auth
}));
//API Implementation

//GET -> To fetch data
//POST -> To create data
//PUT -> To update data
//DELETE -> To delete data
app.use(express.json()); // this is useful to parse the incoming request body in JSON format
app.use(express.urlencoded({extended:true})); // this is to encode the income request


//POST Request
app.post("/createUser", async(req,res)=>{
    const {name, email, password, role} = req.body;

    //Connect to the schema/ collections

    //create a new object with User

    const newUser = new User({name,email,password,role});
    await newUser.save(); //save the record
    return res.send("User created successfully");
});

//to fetch the details
app.get("/userDetails/:userEmail", async(req,res)=>{
    try{
        const {userEmail} = req.params;
        // console.log("userId - "+userId);
        const isUserExisted = await User.find({email : userEmail}); // entire document
        if(isUserExisted!==null){
            return res.send(isUserExisted);
        }else
        {
            return res.send("no user found with given email "+ userEmail);
        }
        
    }
    catch(err){
        console.log("error occurred while fetching user details - ",err);
    }
})

//DELETE
app.delete("/deleteUserDetails/:userEmail", async(req,res)=>{
try{

    //1. first get the record from the db using userEmail
    const {userEmail} = req.params;
    const isUserExisted = await User.find({email:userEmail});
    console.log("IsUserExisted", isUserExisted);
    if(isUserExisted.length>0){
        //2. delete the record
        await User.deleteOne({email:userEmail});
        // await User.save();

        return res.send("User with "+userEmail+" deleted successfully");
    }else{
        return res.send("No user found with given email "+ userEmail);
    }
}
catch(err){
    console.log("error occurred while deleting user details - ",err);
    return res.send("error occurred while deleting user details - ");
}

});

//PUT -> To update a record
app.put("/updateUserDetails/:userId", async(req,res)=>{
    try{

        //1. find the record with userId
        const isUserExisted = await User.findById(req.params.userId);
        const { newUserName, newUserEmail, newUserPassword, newUserRole} = req.body;
        if(isUserExisted){
            //2. update the record with new data
            isUserExisted.name = newUserName;
            isUserExisted.email = newUserEmail;
            isUserExisted.password = newUserPassword;
            isUserExisted.role = newUserRole;  

            await isUserExisted.save(); //saves the updated record
            return res.send("User details updated successfully");
        }else{
            return res.send("No user found with given userId "+ req.params.userId);
        }
    }
    catch(err){
        console.log("error occurred while updating user details - ",err);
        return res.send("Error occurred while updating user details");
    }
});

app.get("/getAllUsers", async(req,res)=>{
    try{
        const allUsers = await User.find({});
        return res.send(allUsers);
    }
    catch(err){
 console.log("error occurred while fetching all user details - ",err);
        return res.send("error occurred while fetching all user details");
    }
})

app.listen(port,()=>{
    console.log(`Server is running on port ${port}`);
})