const mongoose = require("mongoose");
//Schemas are collections/tables in sql
//name, email, password, role
const userSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email:{
        type:String,
        required:true
    },
    role:{
        type:String,
        required:true
    },
    department:{
        type:String,
        required:true
    },
    profile:{
        type : String,
        required: true
    }
});

module.exports = EmployeeModel = mongoose.model("SkillLaddersUsers", userSchema);