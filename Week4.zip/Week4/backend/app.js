const express = require("express");
const app = express(); // express obj
const port = 7000;
const db = require("./dbconnection.js");
const Employee = require("./EmployeeCollection.js");

//middlewares
const cors = require("cors");
app.use(cors({
    origin: "http://localhost:3000", // your React app URL
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true // if using cookies/auth
  }));
app.use(express.json());
app.use(express.urlencoded({extended:true}))


//APIs will be developed
//requirements : request, response

//Types -> POST, GET, PUT, DELETE


// app.get("/skillLadders", (req, res) => {
//     res.send("Hello World From Skill ladders");
// });

//POST
app.post("/createEmployee", async (req,res)=>{
    try{
        const { empName, empEmail, empRole, empDepartment, empProfile} = req.body;
        //check for the empEmail record
        const isEmployeeEmailPresent = await Employee.findOne({email: empEmail});
        console.log("is email present - "+isEmployeeEmailPresent);
        if(isEmployeeEmailPresent){
            return res.send("this email : "+empEmail+" is already present");
        }else{
            //create a new user
            const newUser = new Employee({
                name : empName, email : empEmail , role : empRole, department: empDepartment,
                profile : empProfile
            })
            await newUser.save();
            res.send("Employee created successfully");
        }
    }
    catch(err){
        console.log("error occurred in create employee api : "+err)
    }
});

//Get

app.get("/:empId", async (req,res)=>{
    try{
        const empId = req.params.empId;
        const employeeData = await Employee.findById(empId);
        if(employeeData){
            return res.send(employeeData);
        }else{
            return res.send("employee not found with id : "+empId);
        }

    }catch(err){
        console.log("error occurred in get employee api : "+err);
    }
});

//get all emp
app.get("/fetch/getAllEmp", async (req,res)=>{
    try{
        const empData = await Employee.find({});
        return res.send(empData);
    }
    catch(err){
        console.log("error occurred in getAll emp api : "+err)
    }
})

//update employee
app.put("/updateEmployee/:empId", async (req,res)=>{
    try{
        const empId = req.params.empId;
        const { empName, empEmail, empRole, empDepartment, empProfile} = req.body;
        const updatedEmployee = await Employee.findByIdAndUpdate(empId, {
            name : empName, email : empEmail , role : empRole, department: empDepartment,
            profile : empProfile
        }, { new: true });
        if(updatedEmployee){
            return res.send("Employee updated successfully");
        }else{
            return res.send("Employee not found with id : "+empId);
        }
    }catch(err){
        console.log("error occurred in update employee api : "+err);
    }
});

//delete employee
app.delete("/deleteEmployee/:empId", async (req,res)=>{
    try{
        const empId = req.params.empId;
        const deletedEmployee = await Employee.findByIdAndDelete(empId);
        if(deletedEmployee){
            return res.send("Employee deleted successfully");
        }else{
            return res.send("Employee not found with id : "+empId);
        }
    }catch(err){
        console.log("error occurred in delete employee api : "+err);
    }
});
app.listen(port, () => {  

    console.log("Your server is running on port " + port);
});

