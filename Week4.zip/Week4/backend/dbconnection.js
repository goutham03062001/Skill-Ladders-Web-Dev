const mongoose = require("mongoose");

mongoose.connect("mongodb+srv://gouthamp0306_db_user:m3WFOb326xixz8ck@cluster0.3yclyxi.mongodb.net/", {}).then(() => {
    console.log("Connected to DB");
}).catch((err) => {
    console.log("Error connecting to DB", err);
});