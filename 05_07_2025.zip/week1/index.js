console.log("Hello world");

function onClickEvent(){
    const mainContainer = document.getElementsByClassName("mainContainer");
    console.log("main container");
    mainContainer[0].classList.add("darkBackground");
    const color = document.getElementById("btn").innerText;
    console.log("Color - "+color)
    if(color==="Black"){
        console.log("Black block")
        document.getElementById("btn").innerText = "White"
        document.getElementById("btn").style.backgroundColor = "white";
        document.getElementById("btn").style.color = "black";
        mainContainer[0].classList.remove("whiteBackground");
        mainContainer[0].classList.add("darkBackground");

    }else{
        console.log("White block")

        document.getElementById("btn").innerText = "Black"
    document.getElementById("btn").style.backgroundColor = "black";
    document.getElementById("btn").style.color = "white";
    mainContainer[0].classList.remove("darkBackground");
    mainContainer[0].classList.add("whiteBackground");
    }    
}