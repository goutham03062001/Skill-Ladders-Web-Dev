console.log("Welcome to JS DOM Concepts");

function changeText(){

    //this is with tag name
    // console.log("Clicked on button");   
    // let title = document.getElementsByTagName("h3")[0].innerText; //JS DOM Concepts
    // console.log(title);
    // //title = "Content changed using JS DOM"; // replaced it 

    // document.getElementsByTagName("h3")[0].innerText = "Content changed using JS DOM";


    //this is with id
    let title = document.getElementById("title").innerText;
    console.log(title);
    document.getElementById("title").innerText = "Content changed using JS DOM with ID";
}

function changeTextWithClass(){

    let title = document.getElementsByClassName("title");
    console.log(title);
    document.getElementsByClassName("title")[0].innerText = "Content changed using JS DOM with Class";
}

function changeBgColor(){

    // document.body.style.backgroundColor = "lightblue";

    //check the color 
    // if it is white -> lightblue
    //else change to white
    const bgColor = document.body.style.backgroundColor;
    if(bgColor=="white"){
        document.body.style.backgroundColor = "lightblue";
    }else{
        document.body.style.backgroundColor = "white";
    }
}

function toggleImage(){
    // <img src="image1.jpg" width="200" height="200"/>
 
    //1. get the img tag
    //2. if img tags are there then hide it otherwise create the image

    const isImagePresent = document.getElementsByTagName("img").length;
    if(isImagePresent>0){   

        document.body.removeChild(document.getElementsByTagName("img")[0]);
    }else{
         // <img src="image1.jpg" width="200" height="200"/>
    const imageTag  = document.createElement("img"); // <img/>
    imageTag.src = "image1.jpg"; // <img src="image1.jpg"/>
    imageTag.width = 200;
    imageTag.height = 200;

    console.log(imageTag);

    document.body.appendChild(imageTag);
    }

}