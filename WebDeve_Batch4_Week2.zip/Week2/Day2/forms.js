console.log("Forms loaded.");

function captureUserData(e){
    e.preventDefault();
    //fname, lname,password
    const fname = document.getElementById("fname").value;
    const lname = document.getElementById("lname").value;
    const password = document.getElementById("password").value;

    console.log("User Fname - "+fname+", User Lname - "+lname+" User Password -"+password);

    if(password.length<8){
        const messageParagraph = document.getElementById("message");
        console.log(messageParagraph);
        const errorMessage = "You are password must be 8 characters or above";
        document.getElementById("message").innerText = errorMessage;
        messageParagraph.style.color = "red";
    }else{
        const messageParagraph = document.getElementById("message");
        const successMesssage = "You are eligible to create an account";
        document.getElementById("message").innerText = successMesssage;
            messageParagraph.style.color = "green";
    }
}