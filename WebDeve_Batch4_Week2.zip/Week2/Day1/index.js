// comments in js
//variable types -> let, const, var

//let , var, const -> scope level
let x=10;
let y = 20;
const z = 100; // can not be reassign
//let, var used for same purpose

console.log(x+y);

console.log(x-y);

console.log(x/y);

//String Operations

let fname = "Ramesh";
let sname = "Koka";

console.log(fname+sname); //concatination
console.log(fname[0],fname[5]); //R
console.log("Len of fname - "+ fname.length);

//ifelse conditions

const age = 17;
if(age<18){
    console.log("Minor");
}else{
    console.log("Major");
}

//loops
for(let i=0;i<10;i++){
    console.log("Number -"+(i+1));
}
let i =0;
while(i<10){
    console.log("Number -"+(i+1));
    i++;
}

//GreetStudents();
//Function in js
function GreetStudents(){
    alert("Good Evening Students!");
}

//Arrays

let fruits = ["Apple","Mango","Banana","Orange"];
console.log(fruits);

//Arrays Operations

console.log("fruits arr len - "+ fruits.length);
console.log(fruits[0]);
console.log(fruits[1]);

//insert at last
fruits.push("PineApple");
console.log(fruits);

//remove from last
fruits.pop();
console.log(fruits);

const index = fruits.findIndex(x=>x=="Banana"); // to get the index of an item
console.log("index - "+index);

//foreach loop
fruits.forEach(currentFruit=>console.log("current fruit name - "+currentFruit));
fruits.map(cf=>console.log("current fruit is - "+cf));

//Object in js

const peronsObj = {
    name : "Goutham",
    age : 24,
    occupation : "Software Developer",
    location : "Hyderabad"
};

console.log("person obj details ",peronsObj);
console.log("Person name - "+ peronsObj.name);
console.log("Person occupation - "+ peronsObj.occupation);

//using property names
console.log("Person Age is "+ peronsObj['age'])

//Inner Objects

const personDetails = {
    name : "Goutham",
    age : 24,
    occupation : "Software Developer",
    location : "Hyderabad",
    skills: {
        skillName : "HTML",
        expertLevel:"Professional",
        experience : "5"
    },
    address:{
        Hno:"abcd",
        postBox : "123213",
    }
}

console.log("Person Skillset - ", personDetails.skills);
console.log("Person PostBox - ", personDetails.address.postBox);
