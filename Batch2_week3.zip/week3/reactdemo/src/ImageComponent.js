import React from "react";

function ImageComponent(){
    return(<>

        <p>Hello from Image Component</p> 
        <img src="./image.jpeg" width="300" height="300" alt="image2"/>
    </>)
}

export default ImageComponent;