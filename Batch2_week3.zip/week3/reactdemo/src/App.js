import logo from './logo.svg';
import './App.css';
import FormComponent from './FormComponent';
//named functions
function App() {
  return (
   <>
   <FormComponent name="Skill Ladders" color="green"/>
   </>
  );
}

export default App;
