import React from 'react'

//arrow functions
const WelcomeText = () => {
  return (
    <div className="App">
    <h3>Welcome to react session </h3>
    </div>
  )
}

export default WelcomeText