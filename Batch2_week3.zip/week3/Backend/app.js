//express -> routers ( API Implementation)
//nodemon -> automatically restart the app
//mongodb -> online database ( nosql db)
//jwt -> authentication

const express = require("express");
const app = express();
const dbConnection = require("./dbConnection");
const UserModel = require("./UserSchema");
const port = 7000;

//middlewares
app.use(express.json()); // to parse the incoming request body as json
app.use(express.urlencoded({ extended: false })); // to parse the incoming request body as urlencoded data

//Static Response
//Get type
app.get("/welcome", (req, res) => {
  //req -> to get the input from the user
  //res-> to send the response to the user
  res.send("Hey! Welcome to Skill Ladders Web Dev Session");
});

//CRUD -> CREATE(POST), READ(GET),UPDATE(PUT),DELETE(DELETE)
//1. GET
//2. POST
//3. DELETE
//4. PUT -> Update

//POST
//capture the user details
//username, email, password,role
app.post("/signup", async (req, res) => {
  const { name, email, password, role } = req.body;
  // console.log("Entered user name - "+name);
  // console.log("Entered email - "+email);
  // console.log("Entered password - "+password);
  // console.log("Entered role - "+role);

  //Password should be length of 8 or greater and the role should be full stack developer
  if (password.length < 8) {
    return res.send({
      statusCode: 400,
      message: "Please enter a password with length 8 or greater",
    });
  }
  if (role !== "full stack developer") {
    return res.send({
      statusCode: 400,
      message: "Role should be full stack developer",
    });
  } else {
    console.log("Input validation is correct, inserting a new user");
    const isExisted = await UserModel.find({ email: email });
    console.log(isExisted);
    console.log(
      `User with current email ${isExisted.email} is already existed`
    );
    if (isExisted.length>0) {
        console.log("user is already existed");
        console.log(isExisted);
      return res.send({
        statusCode: 400,
        message: "This email is already existed in the db",
      });
    } else {

      const newUser = new UserModel({
        name,
        email,
        password,
        role,
      });
      const newUserDetails = await newUser.save();
      return res.send({
        message: "User Created Successfully",
        userDetails: newUserDetails,
      });
    }
  }
});

app.get("/getUserDetails/:userId", async(req,res)=>{
    try{

        //1. fetch the user details with userId
        //2. if details found return the details or return null

        const userDetails = await UserModel.findById(req.params.userId);
        if(userDetails!=null){
            return res.send({
                statusCode:200,
                message:"User Details Found",
                userDetails
            })
        }else{
            return res.send({
                statusCode:404,
                message:"User Not Found"
            })
        }

    }
    catch(err){
        console.log("Error Occurred while fetching user details")
    }
})

app.delete("/deleteUser/:userId", async(req,res)=>{

    try{
        const deleteUser = await UserModel.findByIdAndDelete(req.params.userId);
        if(deleteUser!=null){
            return res.send({
                statusCode:200,
                message:"User deleted successfully",
                deleteUser
            })
        }else{
            return res.send({
                statusCode:404,
                message:"User Not Found to delete"
            })
        }
    }catch(err){
        console.log("Error Occured while deleting the user")
    }
});

//PUT
app.put("/updateUser/:userId", async(req,res)=>{

    try{
        const updateUser = await UserModel.findByIdAndUpdate(req.params.userId, req.body, {new:true});
        if(updateUser!=null){
            //user is existed 
            // we can update
            updateUser.name = req.body.name;
            updateUser.email = req.body.email;
            updateUser.password = req.body.password;
            updateUser.role = req.body.role;

            const updatedUserDetails = await updateUser.save();
            return res.send({
                statusCode:200,
                message:"User details updated",
                updatedUserDetails
            })
        }else{
            return res.send({
                statusCode:404,
                message:"User Not Found to update"
            }) 
        }
        
    }
    catch(err){
        console.log("Error Occured while deleting the user")
    }
});


app.listen(port, () => {
  console.log("Hello From Backend!");
});
