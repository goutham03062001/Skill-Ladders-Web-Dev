const mongoose = require("mongoose");
const mongoDbConnectionString =
  "mongodb+srv://Goutham:goutham123323@cluster0.ndahzog.mongodb.net/";

mongoose
  .connect(mongoDbConnectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to the database successfully");
  })
  .catch((err) => {
    console.log("Error connecting to the database", err);
  });
