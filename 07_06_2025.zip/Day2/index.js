//let var const


//let -> scope specific
//var -> scope specific
//const -> scope specific , can't update the value

let x = 10;
let y = 20;
let z = x/y;
console.log(z);

//loops

//foreach, for

let items = ["Mango","Jamun","Apple","Orange",2,2.5]
items.forEach(x => {
    console.log(x);
});

//getElementById
//getElementByClassName
//getElementByTagName

function increaseFont(){
    // let para = document.getElementById("para");
    // console.log(para);
    // para.style.color='red';
    // para.style.fontSize = '100px';

    const images = document.getElementById("img1");
    console.log(images);
}