import "./button.css"
function Button(prop){
   
    console.log("inside the button component");
    console.log(prop);
    return (<>
        <button style={{color:prop.color, backgroundColor:prop.background_Color}}>{prop.name}</button>


    {/* <button id="second-button">I'm also a  button</button> */}
    </>)
}

export default Button;