import Button from "./Button";
import Image from "./Image";
import {  useState , useEffect} from "react";
import axios from "axios";
function App(){
const API_URL = "https://v2.jokeapi.dev/joke/Programming";


useEffect(()=>{
  console.log("Hey i called from use effect after refreshing");
 
  async function fetchJokes(){
        const apiResponse = await axios.get(API_URL);
  console.log(apiResponse);
  setJokesData(apiResponse.data);
  }
  fetchJokes();
},[])

//UseState Hook
//Data Manipulation, capturing, handling, storing
//variable.   function
const[count,setCount] = useState(0);
const[userName,setUserName] = useState(null);
const[userEmail,setUserEmail] = useState("");
const[jokesData,setJokesData] = useState(null);
//count = 0;
//count = 3

function incrementNumber(){
  return setCount(count+1); //setCount(100)
}

function decrementNumber(){
  const currentCount = count-1;
  return setCount(currentCount);
}

function captureUserInput(e){
  console.log("User input changed");
  console.log(e);
  setUserName(e.target.value);
}

function captureUserEmail(e){
setUserEmail(e.target.value);
}


async function CallJokesAPI(){
  console.log("JOKES API calling");
  console.log(API_URL);


  //GET  - Retrive info from server

  //POST - Create a new record in server

  //PUT - Update in server
  

  //DELETE - Delete from server

  const apiResponse = await axios.get(API_URL);
  console.log(apiResponse);
  setJokesData(apiResponse.data);

}

  const skillLaddersObj = {
    name : "SkillLadders",
    location:"London",
    services:["Web Development","App Development","Full Stack Development"]
  }
  const GoogleObj = {
    name : "Google",
    location:"London",
    services:["Web Development","App Development","Full Stack Development"]
  }

  const companies = [
    {
    name : "SkillLadders",
    location:"London",
    services:["Web Development","App Development","Full Stack Development"]
  }
  
  ,{
    name : "Google",
    location:"London",
    services:["Web Development","App Development","Full Stack Development"]
  }
  ]
  return(
  
<>
    <h1>Hello world</h1>
  <p>This is paragraph</p>
  <Button name="first button" color="red" background_Color="black"/>
  <Button name="second button" color="brown" background_Color="green"/>
  
  {/* <Image/> */}
    <Button name="thIRD Button"/>
    <div>
      <p>{skillLaddersObj.name}</p>
      <p>{skillLaddersObj.location}</p>
      <p>{skillLaddersObj.services}</p>
    </div>

    {/* iterate through array of objects */}

    <p>Current listed companies : {companies[0].name}</p>
{
  companies.map(current=>{
    return (<p>{current.name}</p>)
  })
}

<p>Count : {count}</p>
<button onClick={incrementNumber}>Increment</button>
<button onClick={decrementNumber}>Decrement</button>


<input type='text' placeholder="Enter your name" style={{width:300,height:30}} name="username"
onChange={(e)=>setUserName(e)}/>

<input type='text' placeholder="Enter your email" style={{width:300,height:30}} name="useremail"
onChange={(e)=>setUserEmail(e.target.value)}/>

<p>{userName && userName.target.value}</p>
<p>{userEmail}</p>


<button onClick={CallJokesAPI}>Create Random Jokes</button>

{
  jokesData && (jokesData.joke && (<>
    <p>{jokesData.category}</p>
    <p>{jokesData.joke}</p>
  </>) || (jokesData.setup &&  (<>
        <p>{jokesData.category}</p>

      <p>{jokesData.setup}</p>
      <p>{jokesData.delivery}</p>
    
  </>)))
}

</>

)
}

export default App;