function Image(){
return (<>

    <img src="./sun-image.jpg"/>
</>)
}

export default Image;