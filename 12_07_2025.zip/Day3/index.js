const person = {
    name : "Goutham",
    age : 25,
    gender : "male",
    height:5.7
};
console.log(person);
console.log("==== PERSON DETAILS ====");
console.log("Person name - ", person.name)
console.log("Person Age - ", person.age)
console.log("Person Gender - ", person.gender)
console.log("Person Height - ", person.height)

//Change the name
person.name = "Sachin";
person.age = 20;
console.log(person);


//loops
//(for in) or (for of)
console.log("Person Gender - ", person["gender"])
for(const propertyName in person){
    console.log(propertyName+"-"+person[propertyName])
}


// function changeText(){
//     //alert("Changing the text");

//     //1. Get the target text
//     //2. update the target text with your own text
//     let customHeading = "Welcome to day 3 session of Skill Ladders Web Dev Course";
//     let heading = document.getElementById("heading");
//     console.log(heading);
//     heading.innerText = customHeading;
// }

function changeBg(){
    //1. get the target button
    //2. Update the target button background color to custom color
    const bgColor = "black";
    const btnTextColor = "white";
    const button = document.getElementById("btn");
    console.log(button);
    button.style.backgroundColor = bgColor;
    button.style.color = btnTextColor;
    button.style.width = "300px";
    button.style.height = "50px";
}