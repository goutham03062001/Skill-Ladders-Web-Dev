function changeBackground(){
    //1.target the body
    //2. change the background color

    const body = document.getElementsByTagName("body");
    console.log(body);
    const innerBody = body[0];
    innerBody.style.backgroundColor = "black";


    //1. target the about section
    //2. change the color to white

    const aboutSection = document.getElementById("about");
    console.log(aboutSection);
    aboutSection.style.color = "white";


    //1. target the hero section
    //2. change the background color to green
    const heroSection = document.getElementsByClassName("hero")[0];
    heroSection.style.backgroundColor = "green";
   
    console.log(heroSection);
}

//Anonymous Function

const greetStudents = function(){
    alert("Good evening! Students");
}


//Arrow Function


const calSum = (a,b) => a+b;
console.log(calSum(100,100));
