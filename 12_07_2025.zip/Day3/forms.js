function onBtnClick(event){
    event.preventDefault();
    // alert("forms working")
    const form = document.getElementById("form");
    console.log(form);
    const usernameInput = form[0];
    const userEmailInput = form[1];
    const userPassword = form[2];
    const userMobile = form[3];

    console.log("User name"+usernameInput.value);
    console.log("User email"+userEmailInput.value);
    console.log("User password"+userPassword.value);
    console.log("User mobile"+userMobile.value);

    //1. target the div showDetails
    const showDetails = document.getElementById("showDetails");
    console.log(showDetails);
    //1. make a proper structure
    //1. Insert name
    const userName = document.createElement("p");
    userName.innerText = usernameInput.value;
    console.log(userName);

    //2. Email
    const userEmail = document.createElement("p");
    userEmail.innerText = userEmailInput.value;
    console.log(userEmail);


    showDetails.appendChild(userName);
    showDetails.appendChild(userEmail);

    //3. Password


    //4. Mobile


}