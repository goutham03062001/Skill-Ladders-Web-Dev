console.log("Hello From Javascript");


//data types
//char, int, float, double, string,bool

//number (int, float, double)
//string (char, group of char)
//null
//boolean (false, true)
//undefined
//object (Person, Car , Computer)

// int x = 10;
// int y = 20;
// int z = x+y

// const, let, var
let x = 10;
let y = 20;
console.log(x+y);

const heading = document.getElementById("heading").innerText;
const para = document.getElementById("para");
console.log(heading + " "+para);

function changeBackground(){
    //alert("Hello there!");
    para.style.fontSize = "50px";
    para.style.backgroundColor="green";
    para.style.color="orange";
}