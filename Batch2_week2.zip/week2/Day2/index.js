greetStudents();
//function with name (or) named functions
function greetStudents(){
    console.log("Welcome to JS Concepts!");
}

//function as expression

const greet_Students = function(){
    console.log("Welcome to JS Concepts! From Function Expression");
}

greet_Students();

//Arrow Functions

const add = (a,b)=>{
    return a+b;
}

const sumOfTwo = add(10,20);
console.log("Sumo of Two"+sumOfTwo)