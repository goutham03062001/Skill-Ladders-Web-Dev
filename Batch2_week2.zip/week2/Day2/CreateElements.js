function insertImage(){
    const imageTag = document.createElement('img');
    imageTag.src="./image1.jpg";
    imageTag.width="300";
    imageTag.height="300";
    
    const body = document.getElementById("body");
    body.appendChild(imageTag)
}