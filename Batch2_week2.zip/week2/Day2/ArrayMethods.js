let fruits = ["Mango","Banana","Apple","PineApple","Guava"];

//print the arr
console.log(fruits);
console.log("First index - "+ fruits[0])

//add element into arr
fruits.push("Promogranate");

console.log(fruits);

fruits.splice(1,2);
console.log(fruits);

const isExisted = fruits.indexOf("Banana");
console.log(isExisted);

//Below functions works on every element
fruits.forEach((currentFruit)=>{
    console.log("Current Fruit name is : "+currentFruit);
})

//Filter
let nonGreenFruits = fruits.filter((currentFruit)=> {return (currentFruit!="Guava" && currentFruit!="Mango") });
console.log("nonGreenFruits Arr - "+nonGreenFruits);

//Map
fruits.map((item)=>{
    console.log("Current item - "+ item);
})