import React from 'react'
import ButtonComponent from "./ButtonComponent"
//Create Component function
//Props
//background-color:'black'
const CustomComponent = ({text, color,backgroundColor}) => {
    console.log("current text-",text);
    const arr = text.split(" ");
    const buttonName = arr[arr.length-1];
    console.log("button name-",buttonName);
    console.log(arr);
  return (
      <div id='appdiv'>
        <p style={{ color: color, backgroundColor:backgroundColor }}>{text}</p>
        <ButtonComponent name={buttonName}/>
   </div>
  )
}

//export component function
export default CustomComponent