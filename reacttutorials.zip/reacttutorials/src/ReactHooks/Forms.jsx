import React,{useState, useEffect} from 'react'

//useEffect => it will execute the code when ever the page loads

const Forms = () => {
    const[userName,setUserName] = useState("");
    const[userEmail, setUserEmail] = useState("test@gamil.com");
    const[jokesData, setJokesData] = useState(null);
    const apiEndPoint = "https://v2.jokeapi.dev/joke/Any";
    useEffect(()=>{
        console.log("useEffect called");
         fetch(apiEndPoint).then((response)=>response.json()).then((data)=>{
            console.log("data-",data);
            setJokesData(data);
         }).catch((err)=>{
            console.log("Error - ",err)
         })
    },[]);

  return (
    <div>
    <input type="text" name="username" id="username" onChange={(e) => setUserName(e.target.value)}/>
    <input type="text" name="useremail" id="useremail" onChange={(e) => setUserEmail(e.target.value)}/>

    <p>Username: {userName}</p>
    <p>UserEmail :{userEmail}</p>
    <p>category - {jokesData?.category}</p>
    <p>Joke - {jokesData?.joke || jokesData?.setup} </p>
    </div>
  )
}

export default Forms