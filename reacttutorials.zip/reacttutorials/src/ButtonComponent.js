import React from 'react'
import './button.css'
const ButtonComponent = ({name}) => {
  return (
    <button>{name}</button>
  )
}

export default ButtonComponent