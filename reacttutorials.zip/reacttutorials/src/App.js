import './App.css';
import CustomComponent from './CustomComponent';
import Forms from "./ReactHooks/Forms";
function App() {
  return (
   <>
   {/*  1. welcome to react*/}
     {/* <CustomComponent text="welcome to react" color="green" backgroundColor="black"/>
    <CustomComponent text="Happy Sunday" color="blue" backgroundColor="lightblue"/>

      <CustomComponent text="Hello Developers!" color="red" backgroundColor="lightcoral"/> */}

      <Forms/>
   </>
  );
}

export default App;
