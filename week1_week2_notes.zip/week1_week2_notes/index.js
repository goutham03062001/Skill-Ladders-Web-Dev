console.log("Hello world!");
/*
    1. Syntax
    2. Operators
    3. Control blocks
    4. Loops
    5. Functions
*/

//Signle Line COMMENT

/*
    Types of variables
    const, let

    const -> block level Scope
          -> once you define it you can not reassing it 
    
    let -> block level scope
        -> no restrictions like const tpe
 
 */


//2 . operators
/*
    1. numbers
    2. strings
    3. object
    4. null
    5. undefined
*/
let i = 10;
let j = 10;
let k = 20.1;
let fruit = "Mango";
let firstLetter = 'A';
let anotherFruit = "Mango";

let c = i+j;
console.log("Sum of"+i+""+j+" "+c);
console.log(`Sum of ${i}, ${j} is ${c}`);


console.log(fruit+" "+anotherFruit);

// console.log(fruit==anotherFruit);
if(fruit===anotherFruit){
    console.log("Yes both are same");
}else{
    console.log("Bro! Both are not same");
}

let personAddress = {
    houseNumber : "2-123/123",
    pinCode : "500081",
    apartmentName : "Suryavanshi residency"
};

let personObj = {
    age : 20,
    name : "Goutham",
    gender : 'M',
    city : "Hyderabad",
    address : personAddress
};



console.log(personObj);
console.log(`Person name is ${personObj.name}`)
console.log(`Person age is ${personObj.age}`);
console.log(`person address pincode is ${personObj.address.pinCode}`);


//Loops
/*
    1. For loop
    2. foreach loop
*/
for(let i=0;i<10;i++){
    console.log("Hello world "+(i+1));
}

//arrays
const cars = ["BMW", "Volvo", "Saab", "Ford"]; //object
const cities = ["Hyerabad","Mumbai","Delhi","Chennai"]
for(let i=0;i<cars.length;i++){
    console.log(cars[i]);
}
//1. add method
cars.push(1);//5


for(let i=0;i<cars.length;i++){
    console.log(cars[i]);
}

//2. POP

cars.pop();//5-1 = 4
console.log("After POP method");
for(let i=0;i<cars.length;i++){
    console.log(cars[i]);
}

//findexIndex -> if item is found -> index number
//              otherwise -> -1

let index = cars.findIndex((curritem)=>curritem==="Tata");//-1
if(index>0){
    console.log("Tata is found");
}else{
    console.log("Tata is not found");
}

const mergedArray = cars.concat(cities);
console.log("After merging - "+mergedArray);


cars.forEach((currentCar)=>{
    if(currentCar==="Volvo"){
        cars.push("Tata");
    }
});

cars.unshift("suzuki");

cars.reverse();


console.log(cars);