console.log("From domconcepts")

function changeH1Content(){
        console.log("You clicked on button");

        const h1Content = document.getElementById("first-heading").innerText;
        console.log(h1Content);
        document.getElementById("first-heading").innerText = "This h1 is changed !!!";

        // console.log("Your h1 content is "+h1Content);

        const images = document.getElementsByClassName("image-container");
        console.log(images);

        const inputsElements = document.getElementsByTagName("input");
        console.log(inputsElements);
}
function hideCars(){
    //1. get the image tags
    //2. hide them
    const images = document.getElementsByTagName("img");
    // images[0].style.display="none";
    for(let i=0;i<images.length;i++){
        images[i].style.display="none";
    }
    
}

function showCars(){
    //1. get the image tags
    //2. hide them
    console.log("show cars funcion");
    const images = document.getElementsByTagName("img");
    console.log(images);
    // images[0].style.display="none";
    for(let i=0;i<images.length;i++){
        images[i].style.display="block";
    }
    
}


const personObj = {
    name : "Goutham",
    age: 25,
    city : "Hyderabad",
    role:"Fullstack software developer",
    experience : 2,
    skills: ["HTML","CSS","JS","React","Node js",".net","SQL","Mongodb"]
}

console.log(personObj.age);
console.log(personObj.name);
console.log(personObj.city);

console.log(personObj);

//object destructring -> you can take what ever properties you want

const {name,age,city} = personObj;
console.log('user name is '+name);

//convert js object into json
const jsonObject = JSON.stringify(personObj);
console.log(jsonObject);

const jsObject = JSON.parse(jsonObject);
console.log(jsObject);