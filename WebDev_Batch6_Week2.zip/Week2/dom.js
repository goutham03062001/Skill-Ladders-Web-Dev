console.log("Inside the DOM Js")

//getElementsByTagName
const paraTags = document.getElementsByTagName("p");
const headingTags = document.getElementsByTagName("h3");

// document.getElementsByClassName("");

console.log(paraTags);
console.log(headingTags);

function changeH3Color(){
    console.log("Button clicked");
    let content = document.getElementById("heading-3");
    content.style.color="green";
    content.style.fontSize="32px";
    console.log(content);
}

function changeText(){
        let content = document.getElementById("heading-3");
        content.innerText="Hey!! I'm replaced with JS"
}

//Form Validations

/*
    1. Username -> must be of 8 characters
    2. email -> should contain @
    3. password -> must contain 8 characters & 1 small letter & 1 capital
*/

function validateForm(e){
    e.preventDefault();
    const form = document.getElementsByName("myForm")[0];
    const userName = form[0].value;
    const email = form[1].value;
    const password = form[2].value;
    console.log("username - "+userName);
    console.log("email - "+email);
    console.log("password - "+password);


    if(userName=="" || email =="" || password==""){
        return alert("Please fill all the required details");
    }
    if(userName.length<=7){
        return alert("Username must be 8 characters");
    }if(!email.includes("@")){
        return alert(`Please enter valid email address with "@"`)
    }if(password.length>8){
        if(password.includes("/^(?=.*[a-z])(?=.*[A-Z])/")){
            return alert("Password must contain atleast one small and capital letter")
        }
    }else{
        return alert("Password must be 8 chars")
    }


    console.log(form);
}