console.log("Hello World");

//Syntax
//Arthmetic operation
//logical operations


//Types

let x = 10; //number
let y = 20.2;

let z = x+y;
console.log(z);

//difference between let and const

let fruitName = "Mango"; //string
fruitName="Orange";

const vehicleName = 'Tata';
// vehicleName="Breeza";

console.log(fruitName);
console.log(vehicleName);

let bigNumber = BigInt(1234567890123456789012345)//big int
const cars = ["Saab", "Volvo", "BMW"]; //object
let country;//never assigned value
let company = null;//no object value is being mapped

console.log(typeof(x));
console.log(typeof(y));
console.log(typeof(fruitName));
console.log(typeof(vehicleName));
console.log(typeof(bigNumber));
console.log(typeof(cars));
console.log(typeof(country));
console.log(typeof(company));

for(let i=0;i<cars.length;i++){
    console.log("Current car name is "+cars[i]);
}

//string methods
let companyName = "Skill ladders";
let service1 = "App Developemnt";
let service2 = "Web Development";
let info = companyName+service1+service2+"Tutorials";

let interpolationString = `Welcome to ${companyName} ${service1} ${service2}`

console.log(info);
console.log(interpolationString);

let text = `He's often called "Johnny""`;
console.log(text);


function Calculate(x,y){
    console.log(x+y);
}
Calculate(10,20); //type 1 ->void function


function returnStringConcatination(x,y){
    return x+" "+y+" Concatinated";
}

let completeString = returnStringConcatination("Hello","World");
console.log(completeString);


//Annonymous functions

const mult = function(x,y){return x*y};

console.log(mult(10,20));

//Arrow functions

const square = (a)=>a**2;
console.log(square(10));


//Objects

let personObj = {

        PersonName : "Goutham", //properties
        age : "25",
        gender:"Male",

        printDetails : function(){
            return `${this.PersonName} ${this.age} ${this.gender}`;
        } //methods
};
console.log(personObj);
console.log("Person name  is "+personObj.PersonName);
console.log("Person age "+personObj.age);
console.log(personObj.printDetails());


//Arrays

const array = ["Saab", "Volvo", 1,1234567891232n,"Mango"]; //object
const veg = ["Brinjal","Tomato","BottleGaurd"];
console.log(array);


console.log(array[0]);
console.log(array[1]);

array.forEach(curr=>{
    console.log(curr);
})

const mergedArr = array.concat(veg);
console.log(mergedArr);

array.push(10);
console.log(array);
