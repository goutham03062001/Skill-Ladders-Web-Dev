function Submit(e){
    e.preventDefault();
    console.log("Inside the submit function");


    //Form with id

    const userName = document.getElementById("signup")[0].value;
    const userEmail = document.getElementById("signup")[1].value;
    const userMobile = document.getElementById("signup")[3].value;
    const userPassword = document.getElementById("signup")[2].value;

        console.log("User name - "+ userName);
        console.log("User email - "+userEmail);
        console.log("User mobile - "+ userMobile);
        console.log("User password - "+ userPassword);
        var totalCount = 0;
        //1. username ->  6 or more characters
        //2. email -> should contain @  character
        //3. mobile -> should be 10 digits
        //4. password -> should contain atleast 8 characters, 1 uppercase, 1 lowercase, 1 special character and 1 number

        if(userName.length < 6){
            // alert("Username should be atleast 6 characters");
        document.getElementById("usernamewarning").innerText = "Username should be atleast 6 characters";
        }else{
               document.getElementById("usernamewarning").innerText = "";
                totalCount++;
        }
        if(!userEmail.includes("@")){
            document.getElementById("useremailwarning").innerText = "Email should contain @ character";
        }else{
                       document.getElementById("useremailwarning").innerText = "";
                       totalCount++;
        }
        if(userMobile.length < 9){
            document.getElementById("usermobilewarning").innerText = "Mobile number should be 10 digits";
        }else{
            document.getElementById("usermobilewarning").innerText = "";
            totalCount++;
        }
        if(userPassword.length < 8 || !/[A-Z]/.test(userPassword) || !/[a-z]/.test(userPassword) || !/[0-9]/.test(userPassword) || !/[!@#$%^&*]/.test(userPassword)){
            document.getElementById("userpasswordwarning").innerText = "Password should contain atleast 8 characters, 1 uppercase, 1 lowercase, 1 special character and 1 number";
        }else{
        document.getElementById("userpasswordwarning").innerText = "";
                totalCount++;
        }
        console.log("total count ", totalCount);
        if(totalCount === 4){
            //All the validations are valid
            document.getElementById("successMessage").innerHTML = "<p class='success'> You are successfully registerd </p>";
        }
        //getElementByClass
        //getElementByTagName
        //loops -> for, while, foreach, map functions, array method, objects
    }