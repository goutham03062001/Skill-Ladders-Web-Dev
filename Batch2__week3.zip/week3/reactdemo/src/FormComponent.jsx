import React,{useState,useEffect} from "react";
import axios from "axios";
function FormComponent({name, color}){

    const[userName, setUserName]=useState("");
    const[userEmail, setUserEmail] = useState("abcd@gmail.com");
    const[jokesData,setJokesData] = useState(null);
    const apiEndPoint = "https://v2.jokeapi.dev/joke/Programming";
    //It exectues after the page reloads 
    useEffect(()=>{
       axios.get(apiEndPoint).then((data)=>{
        console.log(data);
        setJokesData(data.data)
       }).catch((err)=>{
        console.log(err);
       })
    },[])
    return(<>
    <p style={{color: color, fontSize:'20px'}}>Fill Your Details to signup into {name}</p>
    <form>
        <input type="text" placeholder="Name"  onChange={(e)=>setUserName(e.target.value)} />
        <input type="email" placeholder="Email" onChange={(e)=>setUserEmail(e.target.value)}/>
        <button type="submit">Submit</button>
    </form>
    <p>Your Name {userName}</p>
    <p>Your email {userEmail}</p>

    <br/>

    <p>Jokes Details</p>
    <p>Jokes is : { jokesData && jokesData?.setup || jokesData && jokesData?.joke}</p>
    <p>Joke Category : {jokesData && jokesData?.category}</p>
    </>)
}

export default FormComponent;