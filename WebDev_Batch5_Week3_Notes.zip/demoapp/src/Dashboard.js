function Dashboard({color, fontSize}){
    return(
    <>
    <h1 style={{color:color,fontSize:fontSize}}>Dashboard</h1>

    </>);
}

export default Dashboard;