import logo from './logo.svg';
import './App.css';
import FormComponent from "./Components/Forms/FormComponent";
import JokesComponent from "./Components/Jokes/JokesComponent"
function App() {
  return (
   <>
    <h1>Welcome to React Hooks</h1>
    <FormComponent/>
    <JokesComponent/>
   </>
  );
}

export default App;
