import axios from "axios";
import {useEffect, useState} from "react";


function JokesComponent(){
    const[joke, setJoke] = useState(null);
    useEffect(()=>{

        setTimeout(async ()=>{
    let ApiEndPoint = "https://v2.jokeapi.dev/joke/Programming?type=single";
    const jokesData = await axios.get(ApiEndPoint);
    console.log(jokesData);
    if(jokesData!=null){
        setJoke(jokesData.data.joke);
    }
        },2000)

    },[])

    return(<>
        <p>Jokes Comes Here</p>
        <p> {joke} </p>
    </>)
}

export default JokesComponent;