//1. State management - hooks
// Hooks
/*

    Hooks - variables -> bounded to only one filed
    useState -> forms
    useEffect -> when reload happens

*/
import {useState, useEffect} from 'react'

function FormComponent(){
/*
    Pure javascript
*/
// variable , function 
const[userEmail,setUserEmail] = useState(''); //defining state
const[userPassword, setUserPassword] = useState('');
const[counter,setCounter] = useState(100); // counter = 0
// userEmail = '';
// setUserEmail("test@gmail.com"); -> userEmail = "test@gmail.com"

//HTTP Protocal -> 

//METHODS -> POST, GET, PUT, DELETE

//STATUS CODE -> 200

useEffect(()=>{
    setTimeout(()=>{
    const body = document.getElementsByTagName('body')[0];
    body.style.backgroundColor = "green"
        
    },2000);

    setTimeout(()=>
    {
            const body = document.getElementsByTagName('body')[0];
    body.style.backgroundColor = "white";
    },4000)
},[]);

    return(<>
        <form>
  <div className="form-group">
    <label for="exampleInputEmail1">Email address : {userEmail}</label>
    <input type="email"
     className="form-control" 
     id="exampleInputEmail1" 
     aria-describedby="emailHelp"
      placeholder="Enter email"
      onChange={(e)=>setUserEmail(e.target.value)}  
      />
    <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div className="form-group">
    <label for="exampleInputPassword1">Password {userPassword}</label>
    <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password"
        onChange = {(e)=>setUserPassword(e.target.value)}
    />
  </div>
        <p>Counter - {counter} </p>
        {/* <button onClick={ ()=> setCounter(counter+1)}> Increase </button> */}
  <button type="submit" className="btn btn-primary">Submit</button>
</form>
    </>)
}

export default FormComponent;