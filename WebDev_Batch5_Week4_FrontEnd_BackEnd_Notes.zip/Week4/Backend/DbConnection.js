const mongoDb = require("mongoose"); 

mongoDb.connect("mongodb+srv://gouthamp0306_db_user:9OPsXjF8INLR75Z1@cluster0.p0ybeet.mongodb.net/").then((sucess)=>{
    console.log("Db Connected Successfully");
}).catch((err)=>{
    console.log("Db Connection Failed");
    console.log(err);
});