const mongoose = require("mongoose");

//new collection -> new table
const userSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email:{
        type:String,
        required:true
    },
    role:{
        type:String,
        required:true
    },
    department:{
        type:String,
        required:true
    },
    profile:{
        type : String,
        required: true
    },
    password:{
        type : String,
        required: true
    }
});

module.exports = User = mongoose.model("SkillLaddersUsers", userSchema);