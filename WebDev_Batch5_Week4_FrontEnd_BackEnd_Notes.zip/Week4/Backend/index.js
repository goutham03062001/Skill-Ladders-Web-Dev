const express = require("express");
const app = express(); // instance of express
const dbConnection = require("./DbConnection");
const User = require("./User.js");
const cors = require("cors");
const port = 7000;
app.use(cors({
    origin: "http://localhost:3000", // your React app URL
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true // if using cookies/auth
  }));
app.use(express.json());
app.use(express.urlencoded({extended:true}))

/*Middleware

Client -> Server ->  process request-> send response

Client-> Server-> Middleware (validates data) -> api logic-> proccess req -> send response
*/

//get


//routes starts

// 1. Authentication(signup,login) -> /api/auth/signup, /api/auth/login
// 2. dashboard
// 3. payment
// 4. orders

//routes ends
//get, post, put, delete -> HTTP Methods
app.get("/sayhello",(req,res)=>{
    
    return res.send("Hello From Expresss");
});

app.post("/signup", async(req,res)=>{

    const {name, email, role, department,password, profile} = req.body;
    //log the api request
    console.log("Signup api request");
    console.log(req.body);
    //check for the email existing

    const isEmailExists = await User.findOne({email});

    if(isEmailExists){
        return res.send({
            statusCode : 400,
            messsage : `${email} is already existed`
        })
    }else{
    const newUser = new User({
        name, email, role, department, profile,password
        });
        await newUser.save();
        return res.send({
            status: 200,
            message : `User created with ${email}`
        });
    }
});

app.post("/login", async(req,res)=>{
    try{
        const { email, password} = req.body;
    const isEmailExisted = await User.findOne({email});
    if(isEmailExisted){
        //check password
        const actualPassword = isEmailExisted.password;
        if(password===actualPassword){
            return res.send({
                statusCode: 200,
                message : "Logged In Successfully",
                userDetails : isEmailExisted
            })
        }else{
            return res.send({
                statusCode : 400,
                message : "Password is wrong",
                userDetails : null
            })
        }
    }else{
        return res.send({
            statusCode : 400,
            message : "Email is not existed, login failed"
        })
    }
    }catch(err){
        console.log("ERROR Occurred in login api");
    }
})

//put -> to update details in the db
app.put("/updatePerson/:id",async(req,res)=>{
    try{
        //check the id in the db
        const {id} = req.params;
        const {name, email, role, department,password, profile} = req.body;

        const isUserExisted = await User.findOne({_id : id});
        if(isUserExisted){
            //update the details
            isUserExisted.name = name;
            isUserExisted.email = email;
            isUserExisted.role = role;
            isUserExisted.department = department;
            isUserExisted.password = password;
            isUserExisted.profile = profile;

           await   isUserExisted.save();
            return res.send({
                statusCode : 200,
                message : `${isUserExisted.name} details updated successfully`
            });

        }else{
           return res.send({
            statusCode : 400,
            message : "Can not find user to update"
        }) 
        }
    }catch(err){
        console.log("error occurred in update api"+err);
    }
})

app.get("/fetchAllUsers", async(req,res)=>{
    try{
        const users = await User.find({});
        return res.send({
            statusCode : 200,
            users : users
        })
    }catch(err){
        console.log("error occurred in fetchall users api")
    }
})

//delete api

app.delete("/deleteuser/:id",async(req,res)=>{
    try{
        const { id } = req.params;
         const isUserExisted = await User.findByIdAndDelete({_id : id}); 
         if(isUserExisted!=null){
            return res.send({
                statusCode : 200,
                message : `${isUserExisted.name} is deleted successfully`,
                data : isUserExisted
            })
         }else{
            return res.send({
                statusCode : 400,
                message : `${id} is not existed in db`
            })
         }
    }catch(err){
        console.log("error occurred in delete api");
    }
})

app.listen(port, ()=>{
    console.log("Port is listening on - "+port);
})