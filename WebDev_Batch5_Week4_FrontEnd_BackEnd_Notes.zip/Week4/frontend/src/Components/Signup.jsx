import {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import axios from "axios";
function Signup() {
    const[userName,setUserName] = useState('');
    const[userEmail,setUserEmail] = useState('');
    const[userRole,setUserRole] = useState('');
    const[userDepartment,setUserDepartment] = useState('');
    const[userImage,setUserImage] = useState('');
    const[userPassword,setUserPassword] = useState('');
  const navigate = useNavigate();
    async function handleSignup(e){
        e.preventDefault();
        //call signup api
        const apiEndpoint = "http://localhost:7000/signup";
        const body = {
            name : userName,
            email : userEmail,
            role : userRole,
            department : userDepartment,
            password: userPassword,
            profile : userImage
        };
        const signupApiResponse = await axios.post(apiEndpoint,body);
        //log the signup api 
        console.log(signupApiResponse);
        if(signupApiResponse.data.statusCode===200){
          //navigate user to dashboard
          navigate("/dashboard");
        }else{
          alert("Unable to register your account - "+signupApiResponse.data.message);
        }
    }
  return (
    <div className="container">
        <div className="row"> 
        
       <div className="col-lg-8">
         <form onSubmit={(e)=>{         
            handleSignup(e);
           
         }}>
      <div className="form-group">
        <label>User Name</label>
        <input
          type="text"
          className="form-control"
          name="name"
          onChange={(e) => setUserName(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>User Email</label>
        <input
          type="email"
          className="form-control"
          name="email"
         onChange={(e) => setUserEmail(e.target.value)}
        />
      </div>

      
      <div className="form-group">
        <label>User Password</label>
        <input
          type="password"
          className="form-control"
          name="password"
          onChange={(e) => setUserPassword(e.target.value)} 
        />
      </div>

      <div className="form-group">
        <label>User Role</label>
        <input
          type="text"
          className="form-control"
          name="role"
          onChange={(e) => setUserRole(e.target.value)} 
        />
      </div>

      <div className="form-group">
        <label>User Department</label>
        <input
          type="text"
          className="form-control"
          name="department"
          onChange={(e) => setUserDepartment(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>User Profile</label>
        <input
          type="text"
          className="form-control"
          name="profile"
          onChange={(e) => setUserImage(e.target.value)}
        />
      </div>
      <button className="btn btn-primary btn-md" type="submit">Create New Account</button>
    </form>
         <p>Already have an account? <Link to="/login"
            className="nav-item nav-link"
         >login here</Link>

         </p>
       </div>


        </div>
    </div>
  );
}

export default Signup;
