import { Link, useNavigate } from "react-router-dom";

function Navbar({ isAuth, setIsAuth }) {

  const navigate = useNavigate();

  const handleLogout = () => {

    localStorage.removeItem("Auth");

    setIsAuth(false);

    navigate("/");
  };

  return (
    <>

      <nav className="navbar navbar-expand-lg navbar-light bg-light">

        <Link
          className="navbar-brand"
          to="/"
        >
          UserManagement
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavAltMarkup"
          aria-controls="navbarNavAltMarkup"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >

          <span className="navbar-toggler-icon"></span>

        </button>

        <div
          className="collapse navbar-collapse"
          id="navbarNavAltMarkup"
        >

          <div className="navbar-nav">

            {
              isAuth ? (
                <>

                  <Link
                    className="nav-item nav-link active"
                    to="/dashboard"
                  >
                    Home
                  </Link>

                  <Link
                    className="nav-item nav-link"
                    to="/features"
                  >
                    Features
                  </Link>

                  <button
                    className="nav-item nav-link btn btn-link"
                    onClick={handleLogout}
                    style={{
                      border: "none",
                      background: "none",
                      cursor: "pointer"
                    }}
                  >
                    Logout
                  </button>

                </>
              ) : (
                <>

                  <Link
                    className="nav-item nav-link"
                    to="/login"
                  >
                    Login
                  </Link>

                  <Link
                    className="nav-item nav-link"
                    to="/signup"
                  >
                    Signup
                  </Link>

                </>
              )
            }

          </div>

        </div>

      </nav>

    </>
  );
}

export default Navbar;