import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login({ setIsAuth }) {

  const [userEmail, setUserEmail] = useState('');
  const [userPassword, setUserPassword] = useState('');

  const navigate = useNavigate();

  const handleLogin = () => {

    localStorage.setItem("Auth", true);

    setIsAuth(true);

    navigate("/dashboard");
  };

  return (
    <div className="container">

      <div className="row">

        <div className="col-lg-8">

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleLogin();
            }}
          >

            <div className="form-group">

              <label>Emp Email</label>

              <input
                type="email"
                className="form-control"
                name="empEmail"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
              />

            </div>

            <div className="form-group">

              <label>Emp Password</label>

              <input
                type="password"
                className="form-control"
                name="empPassword"
                value={userPassword}
                onChange={(e) => setUserPassword(e.target.value)}
              />

            </div>

            <button
              type="submit"
              className="btn btn-primary btn-md"
            >
              Login
            </button>

          </form>

        </div>

      </div>

    </div>
  );
}

export default Login;