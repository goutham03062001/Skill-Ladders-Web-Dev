import React, { useState, useEffect } from "react";
import axios from "axios";
import FormComponent from "./FormComponent";

function UpdateModalComponent({ currentEmployeeData }) {
  const [formData, setFormData] = useState({
    empName: "",
    empEmail: "",
    empRole: "",
    empDepartment: "",
    empProfile: ""
  });

  useEffect(() => {
    if (currentEmployeeData) {
      setFormData({
        empName: currentEmployeeData.name || "",
        empEmail: currentEmployeeData.email || "",
        empRole: currentEmployeeData.role || "",
        empDepartment: currentEmployeeData.department || "",
        empProfile: currentEmployeeData.profile || ""
      });
    }
  }, [currentEmployeeData]);

  async function updateEmployee() {
    try {
        const empId = currentEmployeeData._id;
      const updateApiUrl =
        "http://localhost:7000/updateEmployee/" +
        empId;

      const response = await axios.put(updateApiUrl, formData);

      if (response.status === 200) {
        console.log("Employee updated successfully");
        console.log(response);
        return alert("Employee updated successfully, please refresh the page to see the updated list");
      }
    } catch (err) {
      console.log("Error while updating employee", err);
    }
  }

  return (
    <div className="modal" role="dialog" id="updateModal">
      <div className="modal-dialog" role="document">
        <div className="modal-content">

          <div className="modal-header">
            <h5 className="modal-title">Update Employee</h5>
            <button type="button" className="close" data-dismiss="modal">
              <span>&times;</span>
            </button>
          </div>

          <div className="modal-body">
           <FormComponent
  formData={formData}
  setFormData={setFormData}
  isUpdate={true}
/>
          </div>

          <div className="modal-footer">
            <button className="btn btn-primary" onClick={updateEmployee}>
              Update changes
            </button>
            <button className="btn btn-secondary" data-dismiss="modal">
              Close
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}

export default UpdateModalComponent;
