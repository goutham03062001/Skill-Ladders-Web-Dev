import { useState, useEffect } from "react";
import "./App.css";
import axios from "axios";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate
} from "react-router-dom";

import Navbar from "./Components/Navbar";
import Dashboard from "./Components/Dashboard";
import Login from "./Components/Login";
import Signup from "./Components/Signup";
function App() {
  const [empList, setEmpList] = useState([]);
  const [empId, setEmpId] = useState("");
  const [isAuth, setIsAuth] = useState(false);

  const apiEndpoint = "http://localhost:7000/fetch/getAllEmp";

  useEffect(() => {
    let isAuthenticated = localStorage.getItem("Auth");

    if (isAuthenticated) {
      console.log("user is authenticated");
      setIsAuth(true);
    }
  }, []);

  return (
    <BrowserRouter>
      <div>
        <header>
          <Navbar 
          isAuth={isAuth}
          setIsAuth={setIsAuth}/>
        </header>

        <Routes>

          {/* Login Route */}
          <Route
            path="/"
            element={
              isAuth ? (
                <Navigate to="/dashboard" />
              ) : (
                <Login
                  setIsAuth={setIsAuth}
                />
              )
            } 
          />

          {/* Dashboard Route */}
          <Route
            path="/dashboard"
            element={
              isAuth ? (
                <Dashboard />
              ) : (
                <Navigate to="/" />
              )
            }
          />
        <Route path="/login" element={<Login setIsAuth={setIsAuth}/>}/>
        <Route path="/signup" element={<Signup/>}/>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;