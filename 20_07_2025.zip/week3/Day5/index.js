window.onload = function(){
    const taskListContainer = document.getElementById("tasklist");
    const taskCount = taskListContainer.childElementCount;
    console.log(taskCount);
    if(taskCount===0){
        const heading = document.getElementById("tasksHeading");
        heading.innerText = "You do not have task, Please add tasks to see them below"
    }
}
function addTask(event){
    event.preventDefault();
    const form = document.getElementById("taskform")
    const taskName = form[0].value;
    const taskDescription = form[1].value;

    const taskListContainer = document.getElementById("tasklist");
    const taskContainer = document.createElement("div");
    const button = document.createElement("button");
    button.innerText = "remove task";
   
   

    const taskNameContainer = document.createElement("p");
    taskNameContainer.innerText = taskName;
    taskContainer.id = taskName;
    
    const taskDescriptionContainer = document.createElement("p");
    taskDescriptionContainer.innerText = taskDescription;
    taskDescriptionContainer.id = taskDescription;

    button.onclick = function removeTask(){
        console.log("clicked remove task - ",taskName);
        const taskNameDiv = document.getElementById(taskName)
        const taskDescriptionDiv = document.getElementById(taskDescription);
       taskNameDiv.style.display = "none";
       taskDescriptionDiv.style.display = "none"
    }


    taskContainer.appendChild(taskNameContainer);
    taskContainer.appendChild(taskDescriptionContainer);
    taskContainer.appendChild(button)
    taskListContainer.appendChild(taskContainer);

    taskContainer.style.marginTop='30px';
    taskContainer.style.marginBottom='30px';
    taskContainer.style.width = '300px';
    taskContainer.style.height='50px';

    const heading = document.getElementById("tasksHeading");
    heading.innerText = "Your Tasks";

    form[0].value = "";
    form[1].value = "";
}
