function addTask(event){
    event.preventDefault();
    const tasksForm = document.getElementById("taskform");
    console.log(tasksForm);
    const taskNameInput = tasksForm[0].value;
    const taskDescriptionInput = tasksForm[1].value;
  //  console.log(taskNameInput)
   // console.log(taskDescriptionInput);

   let tasklistDiv = document.getElementById("tasklist");
   
   const taskContainer = document.createElement("div");
    //styling margin
    taskContainer.style.marginTop='20px';
    taskContainer.style.marginBottom = '20px';
    taskContainer.style.width = '150px';
    taskContainer.style.height = '100px';
    taskContainer.style.backgroundColor='green';
   const taskNamePara = document.createElement("h3");
   taskNamePara.innerText = taskNameInput;


   const taskDescriptionPara = document.createElement("p");
   taskDescriptionPara.innerText = taskDescriptionInput;

   //create button element to remove the task

   const button = document.createElement("button");
   button.innerText = "remove task";

   //append taskName, taskDescription to the taskContainer

   taskContainer.appendChild(taskNamePara);
   taskContainer.appendChild(taskDescriptionPara);
   taskContainer.appendChild(button);



   //taskContainer should append to tasklistDiv
   tasklistDiv.appendChild(taskContainer);

   //create a remove function
   button.onclick = function(){
    console.log("You clicked on "+ taskNameInput);
    taskContainer.style.display = 'none';
   }

   const taskCount = document.getElementById('tasklist').childElementCount;
   console.log(taskCount);
   if(taskCount>0){
    const taskHeading = document.getElementById("tasksHeading");
    taskHeading.innerText = "You have total tasks"+taskCount;
   }
}