// let cities = ["Hyderabad","Delhi","Indore","Mumbai"];
// let states = ["Telangana","Maharastra","UP","Madhyapradesh"];
// console.log(cities);

//Array methods
//1. Insert  2. Pop 3.Traverse 4. Include

// //1. Insert or add

// cities.push("Banglore");
// console.log(cities)

// //2. Pop
// cities.pop();
// console.log(cities)

// //3. Traverse
// for(let i=0;i<cities.length; i++)
// {
//     console.log(cities[i]+"-");
// }

// //4. Unshift
// cities.unshift("Patna");
// console.log(cities)


// //5. Shift
// cities.shift();
// console.log(cities)

// //6. Length
// console.log("Cities arr length - ",cities.length)

// //7. concat
// let arr = cities.concat(states);
// console.log("After concat - ", arr);

// //8.Find

// let idx = cities.indexOf("Delhi");
// console.log("Index - "+idx);

// //9. Includes
// let isExisted = cities.includes("Jaipur");
// console.log("Mumbai is existed- "+isExisted);


let person = {
    name : "Goutham",
    age : 25,
    gender: "male"
}
console.log(person.name);

//Array of objects
const persons = [
    {
    name : "Goutham",
    age : 25,
    gender: "male"
    },
    {
        name : "Sachin",
        age : 50,
        gender: "male"
    },
    {
        name : "Kajal",
        age : 36,
        gender: "female"
    },
];

console.log(persons);

console.log(persons[0].name);
console.log(persons[1]);
console.log(persons[2]);

//Map, filter methods

//map -> which transforms the each object inside the array of objects


//persons.map(curr=>{console.log(curr.name+" details")});

persons.map((curr)=>{
    console.log(curr.name+" - "+curr.age+" - "+curr.gender);
})
//==
//filter
const res = persons.filter((curr)=>{return curr.gender === "female"});
console.log("female persons details - ",res);

const malePersons = persons.filter((curr)=>{return curr.gender === "male"});
console.log("male persons details - ",malePersons);