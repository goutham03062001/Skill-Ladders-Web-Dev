//express -> routers ( API Implementation)
//nodemon -> automatically restart the app
//mongodb -> online database ( nosql db)
//jwt -> authentication

const express = require("express");
const app = express();
const port = 7000;

//middlewares
app.use(express.json()); // to parse the incoming request body as json
app.use(express.urlencoded({extended:false})); // to parse the incoming request body as urlencoded data

//Static Response
//Get type
app.get("/welcome", (req, res)=>{
    //req -> to get the input from the user
    //res-> to send the response to the user
    res.send("Hey! Welcome to Skill Ladders Web Dev Session")
});

//POST
//capture the user details 
//username, email, password,role
app.post("/signup",(req,res)=>{

    const {name, email, password, role} = req.body;
    // console.log("Entered user name - "+name);
    // console.log("Entered email - "+email);
    // console.log("Entered password - "+password);
    // console.log("Entered role - "+role);

    //Password should be length of 8 or greater and the role should be full stack developer
    if(password.length < 8){
        return res.send({
            statusCode:400,
            message: "Please enter a password with length 8 or greater"
        })
    }if(role!=="full stack developer"){
        return res.send({
            statusCode:400,
            message: "Role should be full stack developer"
        })
    }else{
    return res.send("You are now signed up!");
    }

   
})

app.listen(port, ()=>{
    console.log("Hello From Backend!");
})
