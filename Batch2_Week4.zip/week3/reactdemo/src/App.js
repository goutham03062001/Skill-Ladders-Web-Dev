import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import { useEffect,useState} from 'react';
import User from './User';
function App() {
  const[users,setUsers] = useState(null);

  const[userName, setUserName] = useState(null);
  const[userEmail, setUserEmail] = useState(null);
  const[userPassword, setUserPassword] = useState(null);
  const[userRole, setUserRole] = useState(null);

  const[userCreated,setUserCreated] = useState(null);
  useEffect(()=>{
    async function fetchAllUsers(){
      const response = await axios.get("http://localhost:7000/getAllUsers");
      console.log("Users Records- ",response);
      if(response.data){
        setUsers(response.data.users)
      }
    }
    fetchAllUsers();

  },[])

 async function AddUser(){
  //Call Signup API
  //And insert the details
  const body = {
    name : userName,
    password : userPassword,
    role : userRole,
    email : userEmail
  }
  const res = await axios.post("http://localhost:7000/signup",body);
  if(res.data){
    console.log("Signup API Response - ",res);
    setUserCreated(true);

    setTimeout(() => {
      setUserCreated(false);
    }, 6000);
  }
 }

  return (
   <>
   <h3 className='text text-center'>User Management Dashobard</h3>
   <form>
    <div className='user-details-form col-lg-8'>
      <input type="text" placeholder='enter your name' className='form-control'
      onChange={(e)=>setUserName(e.target.value)}
      />
      <input type="email" placeholder='enter your email' className='form-control'
      onChange={(e)=>setUserEmail(e.target.value)}/>
      <input type="password" placeholder='enter your password' className='form-control'
      onChange={(e)=>setUserPassword(e.target.value)}/>
      <input type="text" placeholder='enter your role' className='form-control'
      onChange={(e)=>setUserRole(e.target.value)}/>

      <button className='btn btn-sm btn-success mt-3'
      onClick={()=>AddUser()}
    >{userCreated ? "New User Created" :"Add User"}</button>
    </div>
   </form>
   <User users = {users}/>
   </>
  );
}

export default App;
