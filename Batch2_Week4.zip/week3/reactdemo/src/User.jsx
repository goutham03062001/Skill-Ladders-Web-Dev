import axios from 'axios';
import React, { use, useState} from 'react'

const User = ({users}) => {
    const[currentClickedUser,setCurrentClickedUser] = useState(null);
    const[userPassword, setUserPassword] = useState(null);
    const[userRole,setUserRole] = useState(null);

    const[isUserUpdated,setIsUserUpdated] = useState(false);
    const[isUserDeleted,setUserDeleted] = useState(false);
    async function updateCurrentUserProfile(currentUpdatingUserDetails){
        console.log("You are trying to update the detils of - "+currentUpdatingUserDetails.name)
        // name, email, password, role
        const updatePayload = {
            name : currentUpdatingUserDetails.name,
            email : currentUpdatingUserDetails.email,
            password : userPassword,
            role : userRole
        }
        //Call the Update API
        const userId = currentUpdatingUserDetails._id;
        const res = await axios.put("http://localhost:7000/updateUser/"+userId, updatePayload);
        console.log("After Updating the userprofile");
        console.log(res);
        if(res.data){
            setIsUserUpdated(true);
            setTimeout(()=>{
                setIsUserUpdated(false);  
            },2000)
        }
    }

    async function deleteCurrentUser(currentDeleteUser){
        const userId = currentDeleteUser._id; 
        const res = await axios.delete("http://localhost:7000/deleteUser/"+userId);
        if(res.data){
            setUserDeleted(true);
            setTimeout(()=>{
                setUserDeleted(false);  
            },5000)
        }
    }
  return (
    <div className='container'>
        <div className="row">
           {
            users && users.map((currentUser,key)=>{
                return(<>
                    <div className='col-lg-4 mt-3' key={currentUser._id}>
                        <div className='card p-2'>
                            <div className="card-content">
                            <p>{ currentUser && currentUser.name}</p>
                            <p>{ currentUser && currentUser.email}</p>
                            <p>{ currentUser && currentUser.role}</p>
                            <button 
                            onClick={()=>setCurrentClickedUser(currentUser)}
                            type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                            View {currentUser.name}
                            </button>
                            </div>
                        </div>
                    </div>
                </>)
            })
           }

        </div>
   

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Clicked On {currentClickedUser && currentClickedUser.name} | {currentClickedUser && currentClickedUser.password} | {currentClickedUser && currentClickedUser.role}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <p>Email : {currentClickedUser && currentClickedUser.email}</p>

        <input type="text" name="password"
        placeholder='Enter your new password'
        className='form-control' onChange={(e)=>setUserPassword(e.target.value)}/>
        {/* <p>Password : { currentClickedUser && currentClickedUser.password} </p> */}

        <input type="text" name="role"
        placeholder='Enter your new role'
        className='form-control' onChange={(e)=>setUserRole(e.target.value)}/>

        {/* <p>Role : {currentClickedUser && currentClickedUser.role}</p> */}
      </div>
      {
        isUserUpdated && (<p>User Details Updated</p>)


      }

      {
        !isUserUpdated && <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"
        onClick={()=>deleteCurrentUser(currentClickedUser)}>
            { isUserDeleted ? "User Deleted Successfully" : "Delete"}
        </button>
        <button type="button" class="btn btn-primary"
        onClick={()=>updateCurrentUserProfile(currentClickedUser)}>Update Profile</button>
      </div>
      }
    </div>
  </div>
</div>
    </div>
  )
}

export default User