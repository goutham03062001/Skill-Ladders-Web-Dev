import { useEffect ,useState} from 'react';
import './App.css';
import Image from "./Image";
import Button from './Button';
import FormComponent from "./FormComponent";
import axios from "axios";
function App() {
const[jokesData,setJokesData] = useState(null);

  // Pure javascript code we will write here
  async function fetchJokes(){
    const res = await axios.get("https://v2.jokeapi.dev/joke/Any?type=single");
    console.log(res);
    if(res.data!=null){
      setJokesData(res.data);
    }

   
  }
  //When page reload this useEffect Hook will trigger
  useEffect(()=>{

    fetchJokes();
    // const timeoutId = setTimeout(() => {
    //   const body = document.getElementsByTagName("body")[0];
    //   body.style.backgroundColor = "red";
    // }, 3000);

    // // Cleanup function to clear the timeout if the component unmounts
    // return () => clearTimeout(timeoutId);
  },[])
  return (
  <div>
    {/* <p>Hello world</p>
    {/* props/input */}
    {/* <Image sourcePath="./image1.jpg"/>
    <Image sourcePath="./image2.jpeg"/>
    <Button text="Learn React"/>
    <Button text="Learn Node js"/>  */}

    <h3 className="text text-center mt-3">CRUD Application</h3>


<FormComponent/>

  </div>

  );
}

export default App;
