import { useState, useEffect } from "react";
import axios from "axios";

function FormComponent() {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [userRole, setUserRole] = useState("");

  const [showModal, setShowModal] = useState(false);
  const [userDetails, setUserDetails] = useState([]);
  const [clickedUserDetails, setClickedUserDetails] = useState(null);

  // ✅ Separate edit states for modal
  const [editUserName, setEditUserName] = useState("");
  const [editUserEmail, setEditUserEmail] = useState("");
  const [editUserPassword, setEditUserPassword] = useState("");
  const [editUserRole, setEditUserRole] = useState("");

  useEffect(() => {
    async function fetchUsers() {
      try {
        const response = await axios.get("http://localhost:7000/getAllUsers");
        console.log("User Details:", response.data);
        setUserDetails(response.data || []);
      } catch (error) {
        console.error("Error fetching users:", error);
        setUserDetails([]);
      }
    }

    fetchUsers();
  }, []);

  async function createNewUserFun(event) {
    event.preventDefault();

    const apiUrl = "http://localhost:7000/createUser";
    const body = {
      name: userName,
      email: userEmail,
      password: userPassword,
      role: userRole,
    };

    try {
      const apiResponse = await axios.post(apiUrl, body);
      console.log("✅ Create User Response:", apiResponse.data);
      alert("User Created Successfully");
      setUserName("");
      setUserEmail("");
      setUserPassword("");
      setUserRole("");
    } catch (error) {
      console.error("❌ Error occurred while creating user:", error);
    }
  }

  function updateState(user) {
    setShowModal(true);
    setClickedUserDetails(user);

    // ✅ Fill modal fields
    setEditUserName(user.name);
    setEditUserEmail(user.email);
    setEditUserPassword(user.password);
    setEditUserRole(user.role);
  }

  async function updateUserFun(event) {
    event.preventDefault();
    const userId = clickedUserDetails && clickedUserDetails._id;
    const apiUrl = "http://localhost:7000/updateUserDetails/" + userId;
    const body = {
      newUserName: editUserName,
      newUserEmail: editUserEmail,
      newUserPassword: editUserPassword,
      newUserRole: editUserRole,
    };
    const response = await axios.put(apiUrl, body);
    console.log("✅ Update User Response:", response.data);
    if (response.data) {
      alert("User with " + userId + " Updated Successfully");
      setShowModal(false);
    } else {
      console.log("Not Updated");
    }
  }

  return (
    <div className="mainContainer">
      <div className="row">
        {/* LEFT: Create User Form */}
        <div className="col-lg-6">
          <form onSubmit={createNewUserFun}>
            <div className="form-group">
              <label htmlFor="exampleInputName">User Name</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputName"
                placeholder="Enter your name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label htmlFor="exampleInputEmail1">Email address</label>
              <input
                type="email"
                className="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
              />
              <small id="emailHelp" className="form-text text-muted">
                We'll never share your email with anyone else.
              </small>
            </div>

            <div className="form-group">
              <label htmlFor="exampleInputPassword1">Password</label>
              <input
                type="password"
                className="form-control"
                id="exampleInputPassword1"
                placeholder="Password"
                value={userPassword}
                onChange={(e) => setUserPassword(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label htmlFor="exampleInputRole">Role</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputRole"
                placeholder="Enter your role"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value)}
              />
            </div>

            <button type="submit" className="btn btn-primary">
              Create User
            </button>
          </form>
        </div>

        {/* RIGHT: Users List */}
        <div className="col-lg-6">
          <h4 className="text text-center mt-3">Users List</h4>
          <div className="row">
            {userDetails.map((user, id) => (
              <div key={id} className="col-lg-10 card mb-3">
                <div className="card-body">
                  <p>{user.name}</p>
                  <p>{user.email}</p>
                  <p>{user.role}</p>
                  <p>{user._id}</p>
                </div>
                <div className="card-body">
                  <button
                    className="btn btn-primary"
                    onClick={() => updateState(user)}
                    type="button"
                    data-toggle="modal"
                    data-target="#exampleModal"
                  >
                    Update
                  </button>
                  <button className="btn btn-danger ml-2">Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* UPDATE MODAL */}
        {showModal && (
          <div
            className="modal fade show"
            id="exampleModal"
            role="dialog"
            style={{ display: "block" }}
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLabel">
                    Update User
                  </h5>
                  <button
                    type="button"
                    className="close"
                    onClick={() => setShowModal(false)}
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div className="modal-body">
                  <form onSubmit={updateUserFun}>
                    <div className="form-group">
                      <label>User Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editUserName}
                        onChange={(e) => setEditUserName(e.target.value)}
                      />
                    </div>

                    <div className="form-group">
                      <label>Email</label>
                      <input
                        type="email"
                        className="form-control"
                        value={editUserEmail}
                        onChange={(e) => setEditUserEmail(e.target.value)}
                      />
                    </div>

                    <div className="form-group">
                      <label>Password</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editUserPassword}
                        onChange={(e) => setEditUserPassword(e.target.value)}
                      />
                    </div>

                    <div className="form-group">
                      <label>Role</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editUserRole}
                        onChange={(e) => setEditUserRole(e.target.value)}
                      />
                    </div>

                    <button type="submit" className="btn btn-primary">
                      Update User
                    </button>
                  </form>
                </div>

                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowModal(false)}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default FormComponent;
