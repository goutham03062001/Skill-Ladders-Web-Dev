import "./ImageStyles.css";
function Image({sourcePath}){
return(<>

    <img src={sourcePath} alt="car picture"/>

</>)
}

export default Image;