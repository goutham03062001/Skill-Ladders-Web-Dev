function Button({text}){
    return(<>
{/* interpolation */}
        <button>{text}</button>
    </>)
}

export default Button;